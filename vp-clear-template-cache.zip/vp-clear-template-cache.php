<?php
/*
Plugin Name: WP Clean Template Cache
Plugin URI: https://www.dorcode.com
Description: Clean WP 4.9 Template cache so page templates and other files are recognized.
Author: Nextvikas
Author URI: https://www.dorcode.com/@vikas
Version: 1.0
*/

if( ! defined( 'ABSPATH' ) ) exit;
if( !class_exists( 'vp_clear_template' ) ) {
	class vp_clear_template {
		function __construct() {
			add_action( 'admin_init', array( $this, 'plugin_setup' ), 10 );
		}
		
		function plugin_setup() {
			add_action( 'admin_bar_menu', array($this, 'add_cache_button'), 999 );
			add_action( 'admin_footer', array($this, 'output_button_script') );
			add_action( 'wp_ajax_vp_bust_file_cache', array( $this, 'handle_cache_bust' ) );
		}
		
		function handle_cache_bust() {
			check_ajax_referer( 'handle_cache_bust', 'nonce' );
			
			global $wpdb;
			$wpdb->query( "DELETE FROM `$wpdb->options` WHERE `option_name` LIKE '_transient_files_%' LIMIT 1" );
			
			wp_die();
		}
		
		function output_button_script() {
			echo '
			<script>
			jQuery(function($) {
				$("#wp-admin-bar-bust_file_cache>a").on("click", function(e) {
					e.preventDefault();
					
					$(this).text("Please wait...");
					$.post(ajaxurl, {"action": "vp_bust_file_cache", "nonce": $(this).attr("href").replace("#", "")}, function() {
						window.location.reload();
					});
				});
			});
			</script>';
		}
		
		function add_cache_button( $wp_admin_bar ) {
			if( is_admin() ) {
				$nonce = wp_create_nonce( 'handle_cache_bust' );
				$wp_admin_bar->add_node( array(
					'id'		=>	'bust_file_cache',
					'title'		=>	'Clear File Cache',
					'href'		=>	'#' . $nonce,
				) );
			}
		}
	}
	
	new vp_clear_template();
}